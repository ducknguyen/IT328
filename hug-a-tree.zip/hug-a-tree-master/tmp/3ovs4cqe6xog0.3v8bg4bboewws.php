 <div class="navbar-fixed-top">
        <div class="top-wrapper">
            <ul class="nav navbar-nav pull-right">
                <li><a href="">ABOUT</a></li> 
                <li>
                    <form class="form-inline">
                    <div class="input-group">
                        <span class="input-group-addon" id="site-search"><i class="fa fa-search" aria-hidden="true"></i></span>
                        <input type="text" class="form-control" placeholder="site search" aria-describedby="site-search">
                    </div>
                    </form>
                </li>
            </ul> 
        </div>
        <nav class="navbar navbar-default bottom-wrapper" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
             <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#home-nav">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            
            <div class="col-md-12">
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="home-nav">
                    <ul class="nav navbar-nav">
                        <li id="logo"><a href="./"><img src="./images/hugatree.png" alt=""></a></li>
                        <li><a href="./hiking">HIKING</a></li>
                        <li><a href="./biking">BIKING</a></li>
                        <li><a href="./chilling">CHILLING</a></li>
                    </ul>
                    <ul class="nav navbar-nav pull-right">
                        <li><a href="./add-location">POST NEW</a></li>
                        <li><a href="./logout">LOGOUT</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
        </nav>
    </div>